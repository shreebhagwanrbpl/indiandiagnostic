"use client";

import { useEffect, useState } from "react";
import { useParams, usePathname } from "next/navigation";
import {
    doc,
    getDoc,
    getDocs,
    addDoc,
    collection,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import toast, { Toaster } from "react-hot-toast";
import styles from "./page.module.css";
import { getCache, setCache } from "@/lib/productsCache";

export default function ProductDetailPage() {
    const { slug } = useParams();
    const pathname = usePathname();

    const [product, setProduct] = useState(null);
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [selectedImage, setSelectedImage] =
        useState("");
    const [selectedMedia, setSelectedMedia] =
        useState("image");
    const [loadingProduct, setLoadingProduct] =
        useState(true);

    /* =====================================================
       WEBSITE
    ===================================================== */

    const WEBSITE = "indiandiagnostic";

    /* =====================================================
       SLUGIFY
    ===================================================== */

    const slugify = (text = "") =>
        text
            .toLowerCase()
            .trim()
            .replace(
                /[^a-z0-9\s-]/g,
                ""
            )
            .replace(/\s+/g, "-");

    /* =====================================================
       LOAD PRODUCT
    ===================================================== */

    useEffect(() => {
        if (!slug) return;

        const fetchProduct = async () => {
            try {
                setLoadingProduct(true);

                let allProducts =
                    await getCache();

                /* =========================================
                   1. CHECK CACHE
                ========================================= */

                if (
                    Array.isArray(allProducts) &&
                    allProducts.length > 0
                ) {
                    const found =
                        allProducts.find(
                            (p) => {
                                const productSlug =
                                    p.slug?.trim()
                                        ? p.slug
                                        : slugify(
                                            p.title ||
                                            p.instrument ||
                                            p.model ||
                                            `product-${p.productId}`
                                        );

                                return (
                                    productSlug ===
                                    slug
                                );
                            }
                        );

                    if (found) {
                        setSelectedImage(
                            found.images?.[0] ||
                            found.image ||
                            ""
                        );

                        setProduct(found);

                        setLoadingProduct(
                            false
                        );

                        return;
                    }
                }

                /* =========================================
                   2. FETCH CATEGORY PRODUCTS
                ========================================= */

                const categoryCollection =
                    collection(
                        db,
                        "websites",
                        WEBSITE,
                        "pages",
                        "categoryproducts",
                        "categories"
                    );

                const categorySnap =
                    await getDocs(
                        categoryCollection
                    );

                const allCategoryProducts =
                    [];

                /* =========================================
                   3. LOOP CATEGORIES
                ========================================= */

                for (
                    const categoryDoc of categorySnap.docs
                ) {
                    const categoryData =
                        categoryDoc.data();

                    const subCollection =
                        collection(
                            db,
                            "websites",
                            WEBSITE,
                            "pages",
                            "categoryproducts",
                            "categories",
                            categoryDoc.id,
                            "subcategories"
                        );

                    const subSnap =
                        await getDocs(
                            subCollection
                        );

                    /* =====================================
                       4. LOOP SUBCATEGORIES
                    ===================================== */

                    subSnap.forEach(
                        (subDoc) => {
                            const subData =
                                subDoc.data();

                            const products =
                                subData.products ||
                                [];

                            products.forEach(
                                (item) => {
                                    allCategoryProducts.push(
                                        {
                                            ...item,

                                            category:
                                                categoryData.category ||
                                                "",

                                            subCategory:
                                                subData.subCategory ||
                                                "",
                                        }
                                    );
                                }
                            );
                        }
                    );
                }

                /* =========================================
                   5. ALL PRODUCTS
                ========================================= */

                allProducts = [
                    ...allCategoryProducts,
                ];

                /* =========================================
                   6. SAVE CACHE
                ========================================= */

                await setCache(
                    allProducts
                );

                console.log(
                    "Total Products =",
                    allProducts.length
                );

                /* =========================================
                   7. FIND PRODUCT
                ========================================= */

                const found =
                    allProducts.find(
                        (p) => {
                            const productSlug =
                                p.slug?.trim()
                                    ? p.slug
                                    : slugify(
                                        p.title ||
                                        p.instrument ||
                                        p.model ||
                                        `product-${p.productId}`
                                    );

                            return (
                                productSlug ===
                                slug
                            );
                        }
                    );

                console.log(
                    "Found Product =",
                    found
                );

                /* =========================================
                   8. SET PRODUCT
                ========================================= */

                if (found) {
                    setSelectedImage(
                        found.images?.[0] ||
                        found.image ||
                        ""
                    );
                }

                setProduct(
                    found || null
                );
            } catch (err) {
                console.error(
                    "Error fetching product in detail page:",
                    err
                );

                setProduct(null);
            } finally {
                setLoadingProduct(
                    false
                );
            }
        };

        fetchProduct();
    }, [slug]);

    /* =====================================================
       CITY
    ===================================================== */

    const pathParts = pathname
        .split("/")
        .filter(Boolean);

    const reservedRoutes = [
        "about",
        "contact",
        "items",
        "services",
    ];

    const city =
        pathParts[0] &&
            !reservedRoutes.includes(
                pathParts[0]
            )
            ? pathParts[0]
                .replace(/-/g, " ")
                .replace(
                    /\b\w/g,
                    (c) =>
                        c.toUpperCase()
                )
            : "India";

    /* =====================================================
       PRODUCT NAME
    ===================================================== */

    const productName =
        product?.title ||
        product?.instrument ||
        product?.model ||
        "Laboratory Equipment";

    /* =====================================================
       QUERY SUBMIT
    ===================================================== */

    const handleSubmit = async () => {
        if (
            !email.trim() ||
            !phone.trim()
        ) {
            toast.error(
                "Please fill all fields"
            );

            return;
        }

        /* =========================================
           EMAIL
        ========================================= */

        const emailRegex =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (
            !emailRegex.test(email)
        ) {
            toast.error(
                "Please enter a valid email"
            );

            return;
        }

        /* =========================================
           PHONE
        ========================================= */

        const phoneRegex =
            /^[6-9]\d{9}$/;

        if (
            !phoneRegex.test(phone)
        ) {
            toast.error(
                "Please enter a valid 10 digit mobile number"
            );

            return;
        }

        const loadingToast =
            toast.loading(
                "Submitting..."
            );

        try {
            await addDoc(
                collection(
                    db,
                    "websitesQueries",
                    WEBSITE,
                    "productQueries"
                ),
                {
                    productName:
                        productName,

                    email:
                        email,

                    phone:
                        phone,

                    createdAt:
                        new Date(),
                }
            );

            toast.success(
                "Query submitted successfully",
                {
                    id: loadingToast,
                }
            );

            setEmail("");
            setPhone("");
        } catch (error) {
            console.error(
                "Query submit error:",
                error
            );

            toast.error(
                "Something went wrong",
                {
                    id: loadingToast,
                }
            );
        }
    };

    /* =====================================================
       LOADING
    ===================================================== */

    if (loadingProduct) {
        return (
            <section
                className={
                    styles.productDetailPage
                }
            >
                <div className="container">
                    <div
                        className={
                            styles.productCardWrap
                        }
                    >
                        <div className="row align-items-center">
                            <div className="col-lg-5">
                                <div
                                    className={
                                        styles.skeletonImage
                                    }
                                ></div>
                            </div>

                            <div className="col-lg-7">
                                <div
                                    className={
                                        styles.skeletonTitle
                                    }
                                ></div>

                                <div
                                    className={
                                        styles.skeletonText
                                    }
                                ></div>

                                <div
                                    className={
                                        styles.skeletonText
                                    }
                                ></div>

                                <div
                                    className={
                                        styles.skeletonText
                                    }
                                ></div>

                                <div
                                    className={
                                        styles.skeletonBtn
                                    }
                                ></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }

    /* =====================================================
       PRODUCT NOT FOUND
    ===================================================== */

    if (!product) {
        return (
            <section
                className={
                    styles.productDetailPage
                }
            >
                <div className="container">
                    <div
                        className={
                            styles.productCardWrap
                        }
                    >
                        <h2>
                            Product Not Found
                        </h2>

                        <p>
                            The requested
                            product could
                            not be found.
                        </p>
                    </div>
                </div>
            </section>
        );
    }

    /* =====================================================
       RENDER
    ===================================================== */

    return (
        <>
            <Toaster position="top-right" />

            <section
                className={
                    styles.productDetailPage
                }
            >
                <div className="container">
                    <div
                        className={
                            styles.productCardWrap
                        }
                    >

                        {/* =====================================
                            PRODUCT MAIN
                        ===================================== */}

                        <div className="row align-items-center">

                            {/* =================================
                                IMAGE
                            ================================= */}

                            <div className="col-lg-5">

                                <div
                                    className={
                                        styles.productImageBox
                                    }
                                >

                                    {selectedMedia ===
                                        "image" && (
                                            <img
                                                src={
                                                    selectedImage ||
                                                    "/no-image.png"
                                                }
                                                alt={
                                                    productName
                                                }
                                                className={
                                                    styles.productDetailImage
                                                }
                                            />
                                        )}

                                    {selectedMedia ===
                                        "video" &&
                                        product.video && (
                                            <video
                                                controls
                                                width="100%"
                                                className={
                                                    styles.productVideo
                                                }
                                            >
                                                <source
                                                    src={
                                                        product.video
                                                    }
                                                    type="video/mp4"
                                                />
                                            </video>
                                        )}
                                </div>

                                {/* =================================
                                    THUMBNAILS
                                ================================= */}

                                <div
                                    className={
                                        styles.thumbnailGallery
                                    }
                                >

                                    {(product.images
                                        ?.length
                                        ? product.images
                                        : product.image
                                            ? [
                                                product.image,
                                            ]
                                            : []
                                    ).map(
                                        (
                                            img,
                                            index
                                        ) => (
                                            <img
                                                key={
                                                    index
                                                }
                                                src={
                                                    img
                                                }
                                                alt={`thumb-${index}`}
                                                className={`${styles.thumbnailItem}
                                                    ${selectedImage ===
                                                        img &&
                                                        selectedMedia ===
                                                        "image"
                                                        ? styles.active
                                                        : ""
                                                    }`}
                                                onClick={() => {
                                                    setSelectedImage(
                                                        img
                                                    );

                                                    setSelectedMedia(
                                                        "image"
                                                    );
                                                }}
                                            />
                                        )
                                    )}

                                    {product.video && (
                                        <div
                                            className={`${styles.mediaThumb}
                                                ${selectedMedia ===
                                                    "video"
                                                    ? styles.active
                                                    : ""
                                                }`}
                                            onClick={() =>
                                                setSelectedMedia(
                                                    "video"
                                                )
                                            }
                                        >
                                            ▶
                                            <span>
                                                Video
                                            </span>
                                        </div>
                                    )}

                                    {product.pdf && (
                                        <a
                                            href={
                                                product.pdf
                                            }
                                            target="_blank"
                                            rel="noreferrer"
                                            className={
                                                styles.mediaThumb
                                            }
                                        >
                                            📄
                                            <span>
                                                PDF
                                            </span>
                                        </a>
                                    )}

                                </div>
                            </div>

                            {/* =================================
                                PRODUCT CONTENT
                            ================================= */}

                            <div className="col-lg-7">

                                <div
                                    className={
                                        styles.productContent
                                    }
                                >

                                    <h1>
                                        {
                                            productName
                                        }
                                    </h1>

                                    <p
                                        className={
                                            styles.productDesc
                                        }
                                    >
                                        {
                                            product.desc
                                        }
                                    </p>

                                    <div
                                        className={
                                            styles.productInfoList
                                        }
                                    >
                                        <p>
                                            <b>
                                                Brand:
                                            </b>{" "}
                                            {
                                                product.brand
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Size:
                                            </b>{" "}
                                            {
                                                product.size
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Usage:
                                            </b>{" "}
                                            {
                                                product.usage
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Model:
                                            </b>{" "}
                                            {
                                                product.model
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Instrument:
                                            </b>{" "}
                                            {
                                                product.instrument
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Automation:
                                            </b>{" "}
                                            {
                                                product.automation
                                            }
                                        </p>

                                        <p>
                                            <b>
                                                Availability:
                                            </b>{" "}
                                            {
                                                product.availability
                                            }
                                        </p>
                                    </div>

                                    {/* =================================
                                        QUERY BOX
                                    ================================= */}

                                    <div
                                        className={
                                            styles.queryBox
                                        }
                                    >
                                        <h3>
                                            Get Product
                                            Details
                                        </h3>

                                        <input
                                            type="email"
                                            className={
                                                styles.queryInput
                                            }
                                            placeholder="Enter Email Address"
                                            value={
                                                email
                                            }
                                            onChange={(
                                                e
                                            ) =>
                                                setEmail(
                                                    e
                                                        .target
                                                        .value
                                                )
                                            }
                                        />

                                        <input
                                            type="tel"
                                            className={
                                                styles.queryInput
                                            }
                                            placeholder="Enter Mobile Number"
                                            value={
                                                phone
                                            }
                                            maxLength={
                                                10
                                            }
                                            onChange={(
                                                e
                                            ) =>
                                                setPhone(
                                                    e.target.value.replace(
                                                        /\D/g,
                                                        ""
                                                    )
                                                )
                                            }
                                        />

                                        <button
                                            className={
                                                styles.queryBtn
                                            }
                                            onClick={
                                                handleSubmit
                                            }
                                        >
                                            Submit Query
                                        </button>
                                    </div>

                                </div>
                            </div>

                        </div>

                        {/* =====================================
                            SEO CONTENT
                        ===================================== */}

                        <div
                            className={
                                styles.seoContent
                            }
                        >

                            <section
                                className={
                                    styles.seoSection
                                }
                            >
                                <h2>
                                    {productName} Supplier
                                    in {city}
                                </h2>

                                <p>
                                    Raj Biosis is a
                                    trusted supplier
                                    and dealer of{" "}
                                    <strong>
                                        {
                                            productName
                                        }
                                    </strong>{" "}
                                    in {city}. We
                                    provide advanced
                                    laboratory
                                    instruments,
                                    pathology
                                    equipment,
                                    diagnostic
                                    analyzers,
                                    hospital
                                    devices, blood
                                    bank equipment
                                    and research
                                    laboratory
                                    solutions for
                                    healthcare
                                    organizations
                                    across {city}.
                                </p>
                            </section>

                            <section
                                className={
                                    styles.seoSection
                                }
                            >
                                <h2>
                                    Leading{" "}
                                    {productName} Dealer
                                    in {city}
                                </h2>

                                <p>
                                    As a reputed{" "}
                                    {productName} dealer
                                    in {city}, we offer
                                    premium quality
                                    equipment from
                                    globally recognized
                                    manufacturers. Our
                                    team provides
                                    installation
                                    support, user
                                    training,
                                    maintenance
                                    guidance and
                                    after-sales
                                    assistance to
                                    ensure smooth
                                    laboratory
                                    operations.
                                </p>
                            </section>

                            <section
                                className={
                                    styles.seoSection
                                }
                            >
                                <h2>
                                    Buy {productName} in{" "}
                                    {city} at Best Price
                                </h2>

                                <p>
                                    Looking to buy{" "}
                                    {productName} in{" "}
                                    {city}? Raj Biosis
                                    offers genuine
                                    products,
                                    competitive
                                    pricing and fast
                                    delivery. We help
                                    hospitals,
                                    diagnostic
                                    centres,
                                    pathology
                                    laboratories and
                                    healthcare
                                    institutions
                                    choose the right
                                    equipment according
                                    to their workflow
                                    and budget.
                                </p>
                            </section>

                            <section
                                className={
                                    styles.seoSection
                                }
                            >
                                <h2>
                                    Applications of{" "}
                                    {productName}
                                </h2>

                                <ul>
                                    <li>
                                        Clinical
                                        Diagnostics
                                        Laboratories
                                    </li>

                                    <li>
                                        Hospitals &
                                        Healthcare
                                        Centres
                                    </li>

                                    <li>
                                        Pathology
                                        Laboratories
                                    </li>

                                    <li>
                                        Blood Banks
                                    </li>

                                    <li>
                                        Medical
                                        Colleges
                                    </li>

                                    <li>
                                        Research &
                                        Development
                                        Laboratories
                                    </li>
                                </ul>
                            </section>

                            <section
                                className={
                                    styles.seoSection
                                }
                            >
                                <h2>
                                    Why Choose Raj Biosis
                                    in {city}
                                </h2>

                                <ul>
                                    <li>
                                        Trusted
                                        Biomedical
                                        Equipment
                                        Supplier
                                    </li>

                                    <li>
                                        Original
                                        Products From
                                        Leading Brands
                                    </li>

                                    <li>
                                        Competitive
                                        Pricing
                                    </li>

                                    <li>
                                        Quick Delivery
                                        Across {city}
                                    </li>

                                    <li>
                                        Technical
                                        Support &
                                        Service
                                        Assistance
                                    </li>

                                    <li>
                                        Experienced
                                        Healthcare
                                        Equipment Team
                                    </li>
                                </ul>
                            </section>

                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}